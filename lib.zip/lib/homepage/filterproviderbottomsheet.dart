import 'package:commercilapp/constant/apiconstant.dart';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:provider/provider.dart';

class DataProvider with ChangeNotifier {
  List<City> cityList = [];
  List<Locationlist> locationList = [];
  List<Categorylist> categoryList = [];
  bool isLoading = false;

  
  List<String> gradeList = [
    "Grade A",
    "Grade B",
    "Grade C",
    "Grade D",
  ]; // Static grade list
  String? selectedGrade; // Holds the selected grade

  // Max and Min values lists
  List<String> maxValues = [
    "10",
    "50",
    "100",
    "150",
    "200",
    "500",
    "1000",
    "5000",
    "10000",
    "15000"
  ];
  List<String> minValues = [
    "10",
    "50",
    "100",
    "150",
    "200",
    "500",
    "1000",
    "10000",
    "15000",
    "50000",
    "85000",
    "1+Lac"
  ];


  Future<void> fetchCityList() async {
    isLoading = true;
    notifyListeners();

    final response = await http.get(Uri.parse('${BaseUrl}api-city-list.php'));

    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body);
      cityList = jsonResponse.map((city) => City.fromJson(city)).toList();
      isLoading = false;
      notifyListeners();
    } else {
      isLoading = false;
      throw Exception('Failed to load city list');
    }
  }

  Future<void> fetchCategoryList() async {
    isLoading = true;
    notifyListeners();

    final response = await http.get(Uri.parse('${BaseUrl}api-city-list.php'));

    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body);
      categoryList = jsonResponse.map((cat) => Categorylist.fromJson(cat)).toList();
      isLoading = false;
      notifyListeners();
    } else {
      isLoading = false;
      throw Exception('Failed to load category list');
    }
  }

  Future<void> fetchLocationList(int? cityId) async {
    if (cityId == null) return;

    isLoading = true;
    notifyListeners();

    final response = await http.get(Uri.parse('${BaseUrl}api-locations-list.php?id=$cityId'));

    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body);
      locationList = jsonResponse.map((data) => Locationlist.fromJson(data)).toList();
      isLoading = false;
      notifyListeners();
    } else {
      isLoading = false;
      throw Exception('Failed to load locations');
    }
  }
}

// Models (example)
class City {
  final int id;
  final String name;

  City({required this.id, required this.name});

  factory City.fromJson(Map<String, dynamic> json) {
    return City(
      id: json['id'],
      name: json['name'],
    );
  }
}

class Locationlist {
  final int id;
  final String name;

  Locationlist({required this.id, required this.name});

  factory Locationlist.fromJson(Map<String, dynamic> json) {
    return Locationlist(
      id: json['id'],
      name: json['name'],
    );
  }
}

class Categorylist {
  final int id;
  final String name;

  Categorylist({required this.id, required this.name});

  factory Categorylist.fromJson(Map<String, dynamic> json) {
    return Categorylist(
      id: json['id'],
      name: json['name'],
    );
  }
}




class BottomSheetContent extends StatefulWidget {
  @override
  _BottomSheetContentState createState() => _BottomSheetContentState();
}

class _BottomSheetContentState extends State<BottomSheetContent> {
  @override
  void initState() {
    super.initState();
    // Fetch initial data when BottomSheet is opened
    final dataProvider = Provider.of<DataProvider>(context, listen: false);
    dataProvider.fetchCityList();
    dataProvider.fetchCategoryList();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<DataProvider>(
      builder: (context, dataProvider, child) {
        return Container(
          padding: EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // City Dropdown
              DropdownButtonFormField<City>(
                value: null,
                onChanged: (City? newValue) {
                  if (newValue != null) {
                    dataProvider.fetchLocationList(newValue.id);
                  }
                },
                items: dataProvider.cityList.map((City city) {
                  return DropdownMenuItem<City>(
                    value: city,
                    child: Text(city.name),
                  );
                }).toList(),
                decoration: InputDecoration(labelText: 'Select City'),
              ),

              SizedBox(height: 16),

              // Location Dropdown
              DropdownButtonFormField<Locationlist>(
                value: null,
                onChanged: (Locationlist? newValue) {},
                items: dataProvider.locationList.map((Locationlist location) {
                  return DropdownMenuItem<Locationlist>(
                    value: location,
                    child: Text(location.name),
                  );
                }).toList(),
                decoration: InputDecoration(labelText: 'Select Location'),
              ),

              SizedBox(height: 16),

              // Category Dropdown
              DropdownButtonFormField<Categorylist>(
                value: null,
                onChanged: (Categorylist? newValue) {},
                items: dataProvider.categoryList.map((Categorylist category) {
                  return DropdownMenuItem<Categorylist>(
                    value: category,
                    child: Text(category.name),
                  );
                }).toList(),
                decoration: InputDecoration(labelText: 'Select Category'),
              ),

              SizedBox(height: 16),

              // Grade Dropdown
              DropdownButtonFormField<String>(
                value: dataProvider.selectedGrade,
                onChanged: (String? newValue) {
                  setState(() {
                    dataProvider.selectedGrade = newValue;
                  });
                },
                items: dataProvider.gradeList.map((String grade) {
                  return DropdownMenuItem<String>(
                    value: grade,
                    child: Text(grade),
                  );
                }).toList(),
                decoration: InputDecoration(labelText: 'Select Grade'),
              ),

              SizedBox(height: 16),

              // Max Values Dropdown
              DropdownButtonFormField<String>(
                value: null,
                onChanged: (String? newValue) {},
                items: dataProvider.maxValues.map((String maxValue) {
                  return DropdownMenuItem<String>(
                    value: maxValue,
                    child: Text(maxValue),
                  );
                }).toList(),
                decoration: InputDecoration(labelText: 'Select Max Value'),
              ),

              SizedBox(height: 16),

              // Min Values Dropdown
              DropdownButtonFormField<String>(
                value: null,
                onChanged: (String? newValue) {},
                items: dataProvider.minValues.map((String minValue) {
                  return DropdownMenuItem<String>(
                    value: minValue,
                    child: Text(minValue),
                  );
                }).toList(),
                decoration: InputDecoration(labelText: 'Select Min Value'),
              ),
            ],
          ),
        );
      },
    );
  }
}
