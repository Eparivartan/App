import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  String _uid = '18'; // Replace with actual user ID
  Map<String, dynamic>? userDetails; // To hold user details
  bool isLoading = true; // Loading state

  @override
  void initState() {
    super.initState();
    fetchUserDetails();
  }

  Future<void> fetchUserDetails() async {
    try {
      final response = await http.get(Uri.parse('https://mycommercialpal.com/api-profile.php?userid=$_uid'));

      if (response.statusCode == 200) {
        print("Response body: ${response.body}"); // Debugging line
        final List<dynamic> data = json.decode(response.body);

        if (data.isNotEmpty) {
          setState(() {
            userDetails = data[0]; // Get the first user detail
            isLoading = false; // Stop loading
          });
          print(data.toString());
        } else {
          print("No user details found.");
          setState(() => isLoading = false); // Stop loading
        }
      } else {
        // Handle error
        print("Failed to load user data: ${response.statusCode}");
        setState(() => isLoading = false); // Stop loading
      }
    } catch (e) {
      print("Error fetching user details: $e");
      setState(() => isLoading = false); // Stop loading
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Profile Page"),
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : SingleChildScrollView( // To enable scrolling
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("ID: ${userDetails?['id']?.toString() ?? ''}", style: TextStyle(fontSize: 18)),
                    SizedBox(height: 8),
                    Text("First Name: ${userDetails?['userFirstName']?.toString() ?? ''}", style: TextStyle(fontSize: 18)),
                    SizedBox(height: 8),
                    Text("Last Name: ${userDetails?['userLastName']?.toString() ?? ''}", style: TextStyle(fontSize: 18)),
                    SizedBox(height: 8),
                    Text("Email: ${userDetails?['userEmail']?.toString() ?? ''}", style: TextStyle(fontSize: 18)),
                    SizedBox(height: 8),
                    Text("Mobile: ${userDetails?['userMobile']?.toString() ?? ''}", style: TextStyle(fontSize: 18)),
                    SizedBox(height: 8),
                    Text("Password: ${userDetails?['userPassword']?.toString() ?? ''}", style: TextStyle(fontSize: 18)),
                    SizedBox(height: 8),
                    Text("Image URL: ${userDetails?['userImage']?.toString() ?? ''}", style: TextStyle(fontSize: 18)),
                    SizedBox(height: 8),
                    Text("Token: ${userDetails?['userToken']?.toString() ?? ''}", style: TextStyle(fontSize: 18)),
                    SizedBox(height: 8),
                    Text("Status: ${userDetails?['status']?.toString() ?? 'N/A'}", style: TextStyle(fontSize: 18)),
                    SizedBox(height: 8),
                    Text("Add On: ${userDetails?['addOn']?.toString() ?? ''}", style: TextStyle(fontSize: 18)),
                  ],
                ),
              ),
            ),
    );
  }
}
