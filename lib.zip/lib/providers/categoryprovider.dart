import 'package:commercilapp/constant/apiconstant.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class CategoryProvider with ChangeNotifier {
  List<dynamic> _categoryList = [];
  bool _isLoading = true;

  List<dynamic> get categoryList => _categoryList;
  bool get isLoading => _isLoading;

  Future<void> fetchCategoriesList() async {
    final response = await http.get(Uri.parse('${BaseUrl}api-cat-list-page.php'));
    
    if (response.statusCode == 200) {
      _categoryList = json.decode(response.body);
      _isLoading = false;
      notifyListeners();
    } else {
      throw Exception('Failed to load data');
    }
  }
}
